package estrada.edmundo.examenedmundoestrada.ui.gallery

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
//para mensajes
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.navigation.NavigationView
import estrada.edmundo.examenedmundoestrada.databinding.FragmentGalleryBinding

class GalleryFragment : Fragment() {

    private var _binding: FragmentGalleryBinding? = null
    lateinit var name:EditText
    lateinit var lastName:EditText
    lateinit var email:EditText
    lateinit var city:EditText
    lateinit var button: Button
    var edited = false

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    //Guardado de datos
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel =
            ViewModelProvider(this).get(GalleryViewModel::class.java)

        //se ligan las capturas de informacion para cada variable
        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding.root
        name = binding.name
        lastName=binding.lastName
        email=binding.email
        city=binding.city
        button=binding.button

        //espera confirmacion de datos
        button.setOnClickListener{
            register(name.text.toString(), lastName.text.toString(), email.text.toString(), city.text.toString())
        }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

    }

    override fun onPause() {
        super.onPause()
        if(!edited)
            return
        name.setText("")
        lastName.setText("")
        email.setText("")
        city.setText("")
    }

    override fun onResume() {
        super.onResume()
        edited = false
    }

    //Captura de datos en plantilla Usuario
    private fun register(nameString:String, lastNameString:String, emailString:String, cityString:String){
        if (nameString=="" || lastNameString == "" || emailString == "" || cityString == ""){
            Toast.makeText(activity,"Debe llenar todos los campos para completar Registro", Toast.LENGTH_LONG).show()
            return
        }
        val sharedPref = this?.activity?.getPreferences(Context.MODE_PRIVATE)
        val editor = sharedPref?.edit()
        editor?.putString("name", nameString)
        editor?.putString("lastName", lastNameString)
        editor?.putString("email", emailString)
        editor?.putString("city", cityString)
        editor?.apply()

        val navigationView = activity?.findViewById(estrada.edmundo.examenedmundoestrada.R.id.nav_view) as NavigationView
        val headerView = navigationView.getHeaderView(0)
        //Va a la barra de navegacion
        val navUsername = headerView.findViewById<View>(estrada.edmundo.examenedmundoestrada.R.id.email) as TextView
        navUsername.text = nameString + " " + lastNameString
        //Esto ira a la barra de navegacion
        val navEmail = headerView.findViewById<View>(estrada.edmundo.examenedmundoestrada.R.id.email) as TextView
        navEmail.text = emailString


        Toast.makeText(activity,"Registrado Exitosamente", Toast.LENGTH_LONG).show()
        edited = true

    }
}